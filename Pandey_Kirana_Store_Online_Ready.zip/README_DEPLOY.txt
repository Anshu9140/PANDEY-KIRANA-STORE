PANDEY KIRANA STORE - ONLINE DEPLOYMENT

Upload app.py, requirements.txt and render.yaml to GitHub.
Then create a Render Web Service from the repository.
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app

SQLite note: free/ephemeral hosting may lose database data after redeploy/restart. Use persistent storage or PostgreSQL for permanent store data.
Default login in the existing app: admin / 1234. Change it before public use.
